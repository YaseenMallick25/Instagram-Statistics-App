# Instagram-Statistics-App

![Image](/InstaStats.v.10.png)

![Image](/InstaStatsWidget.v.1.0.png)

<p align="center">
  <img src="InstaStats.v.10.gif" alt="animated" />
</p>
