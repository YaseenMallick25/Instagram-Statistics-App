//
//  Backup_InstaStatsApp.swift
//  Backup InstaStats
//
//  Created by Yaseen Mallick on 08/01/21.
//

import SwiftUI

@main
struct InstaStatsApp: App {
    @ObservedObject var fetcher = InstaDataFetcher()
    @State var LoggingStatus = isLoggedIn()
    @State var selection = 1
    
    var body: some Scene {
        WindowGroup {
            if LoggingStatus {
                
                TabView(selection:$selection) {
                    NavigationView {
                        HomeView()
                            .edgesIgnoringSafeArea(.all)
                            .navigationTitle("Home")
                    }
                    .tabItem {
                        Image(systemName: "house")
                        Text("Home")
                    }
                    .tag(1)
                    
                    NavigationView {
                        LogView()
                            .edgesIgnoringSafeArea(.all)
                            .navigationTitle("Breakdown")
                    }
                    .tabItem {
                        Image(systemName: "chart.bar")
                        Text("Breakdown")
                    }
                    .tag(2)
                    
                    NavigationView{
                        ZStack {
                            Image("BGImage1")
                                .resizable()
                                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
                                .offset(y: -10)
                            
                            VStack {
                                Button(action: {
                                    LoggedOut()
                                    self.LoggingStatus = false
                                    self.selection = 1
                                }) {
                                    Image(systemName: "power")
                                        .scaleEffect(2.5)
                                        .padding(.all,40)
                                }
                                .buttonStyle(SimpleButtonStyle())
                                
                                Text ("LogOut")
                            }
                        }
                        .edgesIgnoringSafeArea(.all)
                        .navigationTitle("Log Out")
                    }
                    
                    .tabItem {
                        Image(systemName: "arrow.right.square")
                        Text("LogOut")
                    }
                    .tag(3)
                    
                    
                }
                .edgesIgnoringSafeArea(.top)
                
                .onAppear(perform: {
                    if StillNotFuckedUp() && CanRefresh() {
                        print("Doing Auto Refesh")
                        
                        self.fetcher.username = UserDefaults.standard.object(forKey: "username") as! String
                        self.fetcher.load()
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5 ) {
                            SetRefresh()
                            
                            UpdateRefrences()
                            
                            UpdateHighestFollowerCount()
                            UpdateLowestFollowerCount()
                            
                            UpdateGainLoss()
                            
                            DoLogs()
                            
                        }
                        
                    } else {
                        print("Can't Auto Refresh")
                    }
                })
                
            } else {
                SearchUser(fetcher: self.fetcher, LoggingStatus: self.$LoggingStatus)
                
            }
            
        }
        
    }
    
}

struct SimpleButtonStyle: ButtonStyle {
    let height: CGFloat = 60
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .foregroundColor(configuration.isPressed ? Color.red : Color.white)
            .background(Color.secondary.opacity(1))
            .clipShape(Circle())
    }
}
