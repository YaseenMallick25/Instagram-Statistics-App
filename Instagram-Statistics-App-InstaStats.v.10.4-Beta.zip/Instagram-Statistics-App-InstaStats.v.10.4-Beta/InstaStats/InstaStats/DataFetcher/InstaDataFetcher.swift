//
//  InstaDataFetcher.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation
import WidgetKit

public class InstaDataFetcher: ObservableObject {
    
    @Published var data: InstaData?
    
    var BaseUrl = "https://www.instagram.com/"
    
    @Published var username: String = ""
    
    @Published var FullName: String = ""
    @Published var NewFollowerCount: Int = 0
    @Published var ProfilePic: String = ""
    
    var query = "/?__a=1"
    
// MARK: - TestSharedURL
    
    let TestSharedURL = "https://run.mocky.io/v3/3da0c626-daf9-4e81-8970-92c231b1c439" //13106743
    //let TestSharedURL = "https://run.mocky.io/v3/43699919-5be9-4679-bbd7-b21e9e63186d" //13108217
    
// MARK: - TestSharedURL

    
    func load() {
        
        //guard let url = URL(string: BaseUrl + username + query) else {
        //    print("Invalid URL")
        //    return
        //}
        
        guard let url = URL(string: TestSharedURL) else {
            print("Invalid URL")
            return
        }
        
        //let SharedURL = BaseUrl + username + query
        
        //UserDefaults(suiteName: "group.InstaStats")!.set(SharedURL, forKey: "SharedURL")

        UserDefaults(suiteName: "group.InstaStats")!.set(TestSharedURL, forKey: "TestSharedURL")
        
        WidgetCenter.shared.reloadAllTimelines()
        
        URLSession.shared.dataTask(with: url) {(data,response,error) in
            
            do {
                
                if let data = data {

                    let instadata = try JSONDecoder().decode(InstaData.self, from: data)
                    
                    DispatchQueue.main.async {
                        
                        //print(instadata)
                        self.data = instadata
                        
                        self.NewFollowerCount = instadata.graphql.user.edge_followed_by.count

                        UserDefaults.standard.set(self.NewFollowerCount, forKey: "NewFollowerCount")
                        UserDefaults(suiteName: "group.InstaStats")!.set(self.NewFollowerCount, forKey: "SharedFollowerCount")
                        
                        self.FullName = instadata.graphql.user.full_name
                        UserDefaults.standard.set(self.FullName, forKey: "FullName")
                        UserDefaults(suiteName: "group.InstaStats")!.set(self.FullName, forKey: "SharedFullName")
                        
                        UserDefaults.standard.set(self.username, forKey: "username")
                        UserDefaults(suiteName: "group.InstaStats")!.set(self.username, forKey: "Sharedusername")
                        
                        self.ProfilePic = instadata.graphql.user.profile_pic_url_hd
                        UserDefaults.standard.set(self.ProfilePic, forKey: "ProfilePic")
                        UserDefaults(suiteName: "group.InstaStats")!.set(self.ProfilePic, forKey: "SharedProfilePic")
                        
                        UserDefaults.standard.synchronize()
                        
                        WidgetCenter.shared.reloadAllTimelines()

                    }
                    
                }else {
                    print("No Data")
                }
                
            } catch let jsonError as NSError {
                print("\(jsonError.localizedDescription)")
                print ("Can't Decode Data")
                YouFuckedUp()
            }
               
        }.resume()
        
        SetisLoaded(SetisLoaded: true)
        
    }
}
