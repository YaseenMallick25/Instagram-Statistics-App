//
//  Loss.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - Loss

func SetLoss(Loss: Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Loss, forKey: "Loss")
}

func GetLoss() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "Loss")
}

func CalcLoss() -> Int {
    let Loss = GetRefrenceFollowerCount() - GetLowestFollowerCount()
    return Loss
}
