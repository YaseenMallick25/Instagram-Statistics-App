//
//  Gain.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - Gain

func SetGain(Gains: Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Gains, forKey: "Gain")
}

func GetGain() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "Gain")
}

func CalcGain() -> Int {
    let Gain = GetHighestFollowerCount() - GetRefrenceFollowerCount()
    return Gain
}
