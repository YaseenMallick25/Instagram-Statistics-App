//
//  GetisLoaded.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 05/07/21.
//

import Foundation

func GetisLoaded() -> Bool {
    return UserDefaults.standard.bool(forKey: "isLoaded")
}

func SetisLoaded(SetisLoaded: Bool) {
    
    UserDefaults.standard.set(SetisLoaded, forKey: "isLoaded")
    UserDefaults(suiteName: "group.InstaStats")!.set(SetisLoaded, forKey: "SharedisLoaded")
    
}
