//
//  Refrences.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - Refrence Follower Count

func SetRefrenceFollowerCount(Refrence_FollowerCount: Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Refrence_FollowerCount, forKey: "RefrenceFollowerCount")
    UserDefaults.standard.synchronize()
}

func GetRefrenceFollowerCount() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "RefrenceFollowerCount")
}


// MARK: - Refrence Date

func SetRefrenceDate() {
    let date = Date()
    UserDefaults(suiteName: "group.InstaStats")!.set(date, forKey: "Last_Ref_Followers_Date")
    UserDefaults.standard.synchronize()
}


// MARK: - Updating

func Should_Update_Refrences() -> Bool {
    guard let lastRefFollowersDate = UserDefaults(suiteName: "group.InstaStats")!.object(forKey: "Last_Ref_Followers_Date") as? Date else {
        return true
    }

    if let diff = Calendar.current.dateComponents([.second], from: lastRefFollowersDate, to: Date()).second, diff >= 600 {
        print("Ref Date Updated")
        return true
    } else {
        print("Ref Date is not updated")
        return false
    }
}

func UpdateRefrences() {
    if Should_Update_Refrences() {
        SetRefrenceFollowerCount(Refrence_FollowerCount: GetNewFollowerCount())
        SetHighestFollowerCount(Highest_Follower_Count: GetNewFollowerCount())
        SetLowestFollowerCount(Lowest_Follower_Count: GetNewFollowerCount())
        SetRefrenceDate()
    }
}
