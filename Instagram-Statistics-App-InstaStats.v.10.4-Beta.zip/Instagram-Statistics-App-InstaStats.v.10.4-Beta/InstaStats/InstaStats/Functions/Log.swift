//
//  Log.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 19/04/21.
//

import SwiftUI
import Foundation

// MARK: - LogFollows

func SetFollows(Set_Follows : Array<Int>) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Set_Follows, forKey: "LogFollows")
    UserDefaults.standard.synchronize()
}

func GetFollows() -> Array<Int> {
    let Follows = UserDefaults(suiteName: "group.InstaStats")?.object(forKey: "LogFollows") as? [Int] ?? []
    return Follows
}

func AppendFollows() {
    var Follows = GetFollows()
    
    Follows.append(GetGain())
    
    SetFollows(Set_Follows: Follows)
    UserDefaults.standard.synchronize()
    
}

func UpdateFollows() {
    var Follows = GetFollows()
    let gain = GetGain()
    
    Follows[Follows.endIndex - 1] = gain
    
    SetFollows(Set_Follows: Follows)
    UserDefaults.standard.synchronize()
}

// MARK: - LogUnFollows

func SetUnFollows(Set_UnFollows : Array<Int>) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Set_UnFollows, forKey: "LogUnFollows")
    UserDefaults.standard.synchronize()
}

func GetUnFollows() -> Array<Int> {
    let Follows = UserDefaults(suiteName: "group.InstaStats")?.object(forKey: "LogUnFollows") as? [Int] ?? []
    return Follows
}

func AppendUnFollows() {
    var UnFollows = GetUnFollows()
    
    UnFollows.append(GetLoss())
    
    SetUnFollows(Set_UnFollows: UnFollows)
    UserDefaults.standard.synchronize()
    
}

func UpdateUnFollows() {
    var UnFollows = GetUnFollows()
    let loss = GetLoss()
    
    UnFollows[UnFollows.endIndex - 1] = loss
    
    SetUnFollows(Set_UnFollows: UnFollows)
    UserDefaults.standard.synchronize()
}

// MARK: - LogOverall

func SetOverall(Set_Overall : Array<Int>) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Set_Overall, forKey: "LogOverall")
    UserDefaults.standard.synchronize()
}

func GetOverall() -> Array<Int> {
    let Overall = UserDefaults(suiteName: "group.InstaStats")?.object(forKey: "LogOverall") as? [Int] ?? []
    return Overall
}

func AppendOverall() {
    var Overall = GetOverall()
    
    let gain = GetFollows().last ?? 0
    let loss = GetUnFollows().last ?? 0
    
    let Diff = gain - loss
    
    Overall.append(Diff)
    
    SetOverall(Set_Overall: Overall)
    UserDefaults.standard.synchronize()
    
}

func UpdateOverall() {
    var Overall = GetOverall()
    let Diff = GetGain() - GetLoss()
    
    Overall[Overall.endIndex - 1] = Diff
    
    SetOverall(Set_Overall: Overall)
    UserDefaults.standard.synchronize()
}

//MARK: - LogDays

func SetDays() {
    let date = Date()
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "E"
    let dayOfTheWeekString = dateFormatter.string(from: date)
    
    UserDefaults(suiteName: "group.InstaStats")!.set([dayOfTheWeekString], forKey: "LogDaysOfWeek")
    UserDefaults.standard.synchronize()
}

func GetDays() -> Array<String> {
    return UserDefaults(suiteName: "group.InstaStats")?.object(forKey: "LogDaysOfWeek") as? [String] ?? []
}

func AppendDays() {
    var Days = GetDays()
    
    let date = Date()
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "E"
    let dayOfTheWeekString = dateFormatter.string(from: date)
    
    print("Append Days")
    print(Days)
    Days.append(dayOfTheWeekString)
    print(Days)
    
    UserDefaults(suiteName: "group.InstaStats")!.set(Days, forKey: "LogDaysOfWeek")
    UserDefaults.standard.synchronize()
}

func UpdateDays() {
    var Days = GetDays()
    
    let date = Date()
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "E"
    let dayOfTheWeekString = dateFormatter.string(from: date)
    
    print("Update Days")
    
    Days[Days.endIndex - 1] = dayOfTheWeekString
    
    print("Last Days")
    
    UserDefaults(suiteName: "group.InstaStats")!.set(Days, forKey: "LogDaysOfWeek")
    UserDefaults.standard.synchronize()
}

//MARK: - LogRefrence

func SetLogRefrenceDate() {
    let date = Date()
    UserDefaults(suiteName: "group.InstaStats")!.set(date, forKey: "Last_Log_Ref_Date")
    UserDefaults.standard.synchronize()
}

func Should_Logs() -> Bool {
    guard let lastRefFollowersDate = UserDefaults(suiteName: "group.InstaStats")!.object(forKey: "Last_Log_Ref_Date") as? Date else {
        return true
    }

    if let diff = Calendar.current.dateComponents([.second], from: lastRefFollowersDate, to: Date()).second, diff >= 15 {
        print("Logs Done")
        return true
    } else {
        print("Logs Not Done")
        return false
    }
}

//MARK: - DoLogs

func DoLogs() {
    if Should_Logs() {
        AppendFollows()
        AppendUnFollows()
        AppendOverall()
        AppendDays()
        SetLogRefrenceDate()
    } else {
        UpdateFollows()
        UpdateUnFollows()
        UpdateOverall()
        UpdateDays()
    }
}

extension Array {

    subscript (range r: Range<Int>) -> Array {
        return Array(self[r])
    }

    subscript (range r: ClosedRange<Int>) -> Array {
        return Array(self[r])
    }
}
