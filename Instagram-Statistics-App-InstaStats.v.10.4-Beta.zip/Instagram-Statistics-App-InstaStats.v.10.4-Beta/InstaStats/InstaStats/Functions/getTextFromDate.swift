//
//  getTextFromDate.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 07/09/21.
//

import Foundation

func getTextFromDate(date: Date!) -> String {
    let formatter = DateFormatter()
    formatter.locale = .current
    formatter.dateFormat = "EEEE, MMMM d, yyyy"
    return date == nil ? "" : formatter.string(from: date)
}
