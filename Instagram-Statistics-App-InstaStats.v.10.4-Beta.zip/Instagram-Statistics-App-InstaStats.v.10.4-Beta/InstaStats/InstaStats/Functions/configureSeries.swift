//
//  configureSeries.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 03/08/21.
//
/*
import Foundation
import AAInfographics


func configureSeriesDataArray() -> [AASeriesElement] {
    let chartSeriesArray = [
        AASeriesElement()
            .name("Overall")
            .type(.area)
            .data(GetFollows()),
        
        AASeriesElement()
            .name("Follows")
            .data(GetUnFollows()),
        
        AASeriesElement()
            .name("Unfollows")
            .data(GetOverall()),
        
    ]
    return chartSeriesArray
}
*/
