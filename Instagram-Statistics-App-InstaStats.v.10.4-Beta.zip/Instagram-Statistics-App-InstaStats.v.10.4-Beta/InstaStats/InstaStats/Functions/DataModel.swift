//
//  DataModel.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 19/04/21.
//

import Foundation

// MARK: - Data Model

struct InstaData: Decodable {
    var logging_page_id: String
    var graphql: GraphQLData
}

struct GraphQLData: Decodable {
    var user: UserData
}

struct UserData: Decodable {
    var biography: String
    var edge_followed_by: FollowerData
    var edge_follow: FollowingData
    var full_name: String
    var profile_pic_url_hd: String
    var username: String
}

struct FollowerData: Decodable {
    var count: Int
}

struct FollowingData: Decodable {
    var count: Int
}
