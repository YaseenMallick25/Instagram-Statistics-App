//
//  UpdateGainLoss.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - Update Gain Loss

func UpdateGainLoss() {
    SetGain(Gains: CalcGain())
    print("Gain Set")
    
    SetLoss(Loss: CalcLoss())
    print("Loss Set")
}
