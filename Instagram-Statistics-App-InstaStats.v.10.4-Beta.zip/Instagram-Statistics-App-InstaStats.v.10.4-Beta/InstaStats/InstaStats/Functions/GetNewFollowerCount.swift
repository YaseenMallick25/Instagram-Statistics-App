//
//  GetNewFollowerCount.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 19/04/21.
//

import Foundation

func GetNewFollowerCount() -> Int {
    return UserDefaults.standard.integer(forKey: "NewFollowerCount")
}
