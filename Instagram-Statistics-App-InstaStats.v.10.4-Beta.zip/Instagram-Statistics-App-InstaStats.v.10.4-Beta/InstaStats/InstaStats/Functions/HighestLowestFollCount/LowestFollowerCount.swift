//
//  LowestFollowerCount.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - Lowest Ref Follower Count

func SetLowestFollowerCount(Lowest_Follower_Count: Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Lowest_Follower_Count, forKey: "LowestFollowerCount")
}

func GetLowestFollowerCount() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "LowestFollowerCount")
}

func isLowestFollowerCount() -> Bool {
    if GetNewFollowerCount() < GetLowestFollowerCount(){
        return true
    }
    return false
}

func UpdateLowestFollowerCount() {
    if isLowestFollowerCount() {
        SetLowestFollowerCount(Lowest_Follower_Count: GetNewFollowerCount())
        print("New Lowest")
        print(GetLowestFollowerCount())
    } else {
        print("Lowest not updated")
    }
}
