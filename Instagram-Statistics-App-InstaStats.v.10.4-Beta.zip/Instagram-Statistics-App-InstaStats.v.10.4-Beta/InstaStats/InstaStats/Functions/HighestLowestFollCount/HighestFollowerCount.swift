//
//  HighestFollowerCount.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - Highest Ref Follower Count

func SetHighestFollowerCount(Highest_Follower_Count: Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Highest_Follower_Count, forKey: "HighestFollowerCount")
}

func GetHighestFollowerCount() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "HighestFollowerCount")
}

func isHighestFollowerCount() -> Bool {
    if GetNewFollowerCount() > GetHighestFollowerCount(){
        return true
    }
    return false
}

func UpdateHighestFollowerCount() {
    if isHighestFollowerCount() {
        SetHighestFollowerCount(Highest_Follower_Count: GetNewFollowerCount())
        print("New Highest")
        print(GetHighestFollowerCount())
    } else {
        print("highest not updated")
    }
}
