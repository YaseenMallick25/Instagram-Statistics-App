//
//  Safety.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - For Safety

func YouFuckedUp() {
    let date = Date()
    UserDefaults(suiteName: "group.InstaStats")!.set(date, forKey: "LastRefreshed")
    UserDefaults.standard.synchronize()
    print("You are now fucked up please wait 24 hours to get fucked up again")
}

func StillNotFuckedUp() -> Bool {
    guard let lastRefreshDate = UserDefaults.standard.object(forKey: "LastRefreshed") as? Date else {
        return true
    }

    if let diff = Calendar.current.dateComponents([.hour], from: lastRefreshDate, to: Date()).hour, diff >= 24 {
        print("You are now safe")
        return true
    } else {
        print("Still FuckedUp")
        return false
    }
}
