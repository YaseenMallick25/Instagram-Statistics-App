//
//  RefreshControl.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import Foundation

// MARK: - Refreshing

func CanRefresh() -> Bool {
    guard let WaitForRefresh = UserDefaults(suiteName: "group.InstaStats")!.object(forKey: "WaitForRefresh") as? Date else {
        return true
    }

    if let diff = Calendar.current.dateComponents([.second], from: WaitForRefresh, to: Date()).second, diff >= 5 {
        print("You Can Refresh")
        return true
    } else {
        print("Please wait 30 secs")
        return false
    }
}

func SetRefresh() {
    let date = Date()
    UserDefaults(suiteName: "group.InstaStats")!.set(date, forKey: "WaitForRefresh")
    UserDefaults.standard.synchronize()
    print("Refresh Date Set")
}


