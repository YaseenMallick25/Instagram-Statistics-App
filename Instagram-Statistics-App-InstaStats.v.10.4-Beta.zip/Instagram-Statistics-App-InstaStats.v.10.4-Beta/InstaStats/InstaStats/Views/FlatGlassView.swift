//
//  BlurView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 12/04/21.
//

import Foundation
import SwiftUI
import UIKit

struct FlatGlassView : ViewModifier {
    
    @ScaledMetric var height: CGFloat = 40
    
    func body(content: Content) -> some View {
        if #available(iOS 15.0, *) {
            content
                .padding()
                .frame(height: 50)
                //.frame(width: height)
                //.frame(width: UIScreen.main.bounds.width / 1.5, height: UIScreen.main.bounds.height / 20)
                .background(.ultraThinMaterial)
                .cornerRadius(14)
        } else {
            // Fallback on earlier versions
            content
                .padding()
                .frame(height: 50)
                .cornerRadius(14)
        }
    }
}
