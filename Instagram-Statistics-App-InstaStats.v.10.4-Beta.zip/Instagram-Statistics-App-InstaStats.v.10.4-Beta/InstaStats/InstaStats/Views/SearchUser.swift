//
//  SearchView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import SwiftUI

struct SearchUser: View {
    
    @ObservedObject var fetcher = InstaDataFetcher()
    @State var username = ""
    @State var wait = false
    @Binding var LoggingStatus: Bool
    
    var body: some View {
        
        ZStack {
                
            Image("BGImage1")
                .resizable()
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
            
            if (wait){
                ProgressView()
                    .scaleEffect(1.5)
                    .padding(.top, -150)
                
                Text("  Loading...  ")
                    .font(.headline)
                    .padding(.vertical, 10)
                    .foregroundColor(Color(#colorLiteral(red: 0.8609973575, green: 0.8609973575, blue: 0.8609973575, alpha: 1)))
                    .background(Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)))
                    .cornerRadius(10)
                    .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/1.25)

            }
            
            BlurView(style: .systemUltraThinMaterial)
                .cornerRadius(15)
                .frame(width: UIScreen.main.bounds.width / 1.2 , height: 80)
            
            
            HStack {

                TextField("username", text: self.$username)
                    .padding(.horizontal , 10)
                    .frame(height: 35.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.secondary.opacity(0.8), lineWidth: 1)
                    )
                    .autocapitalization(.none)
                    .padding(.leading,40)
                
                Spacer(minLength: 30)
                
                Button(action: {
                    
                    self.fetcher.username = self.username
                    self.wait.toggle()

                    LoadData()
                    
                    SetGain(Gains: 0)
                    SetLoss(Loss: 0)
                    
                    SetFollows(Set_Follows: [0])
                    SetUnFollows(Set_UnFollows: [0])
                    SetOverall(Set_Overall: [0])
                    SetDays()
                    print("from Search User Days")
                    print(GetDays())
                    
                    waitfunc()

                    if GetisLoaded() {
                        finishedLoggedIn()
                        self.LoggingStatus = true
                        self.wait = false
                        SetisLoaded(SetisLoaded: false)
                    }
                    
                }) {
                    Image(systemName: "arrow.right")
                        .frame(width: 50, height: 35)
                        .background(self.username.isEmpty ? Color.gray : Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .padding(.trailing,40)
                    
                }
                .disabled(self.username.isEmpty)
                
            }
            .padding(.horizontal)
            
        }
        .ignoresSafeArea(edges: .all)
        
    }
    
    func LoadData() {
        
        UserDefaults.standard.set(self.username, forKey: "username")
        UserDefaults(suiteName: "group.InstaStats")!.set(self.username, forKey: "SharedUserName")
        UserDefaults.standard.synchronize()
        
        self.fetcher.load()
        SetRefrenceDate()
        
    }
    
    func waitfunc() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            let NewFollowerCount = UserDefaults.standard.integer(forKey: "NewFollowerCount")
            
            SetHighestFollowerCount(Highest_Follower_Count: NewFollowerCount)
            SetLowestFollowerCount(Lowest_Follower_Count: NewFollowerCount)
            
            SetRefrenceDate()
 
            SetRefrenceFollowerCount(Refrence_FollowerCount: NewFollowerCount)
            print("While setting ref foll")
            print(GetRefrenceFollowerCount())
            print(GetisLoaded())
        }
        
    }
}

func finishedLoggedIn() {
    UserDefaults.standard.set(true, forKey: "isLoggedIn")
    UserDefaults.standard.synchronize()
}

func LoggedOut() {
    let username = ""
    let fullname = ""
    let NewFollowerCount = 0
    let profilepic = ""
    
    UserDefaults.standard.set(username, forKey: "username")
    UserDefaults(suiteName: "group.InstaStats")!.set(username, forKey: "Sharedusername")
    
    UserDefaults.standard.set(fullname, forKey: "FullName")
    UserDefaults(suiteName: "group.InstaStats")!.set(fullname, forKey: "SharedFullName")
    
    UserDefaults.standard.set(NewFollowerCount, forKey: "NewFollowerCount")
    UserDefaults(suiteName: "group.InstaStats")!.set(NewFollowerCount, forKey: "SharedFollowerCount")
    
    UserDefaults.standard.set(profilepic, forKey: "ProfilePic")
    UserDefaults(suiteName: "group.InstaStats")!.set(profilepic, forKey: "SharedProfilePic")
    
    UserDefaults.standard.set(false, forKey: "isLoggedIn")
    
    SetisLoaded(SetisLoaded: false)
    
    SetOverall(Set_Overall: [0])
    SetFollows(Set_Follows: [0])
    SetUnFollows(Set_UnFollows: [0])
    
    UserDefaults.standard.synchronize()
    
    resetDefaults()
}

func resetDefaults() {
    let defaults = UserDefaults(suiteName: "group.InstaStats")
    let dictionary = defaults!.dictionaryRepresentation()
    
    dictionary.keys.forEach { key in
        defaults!.removeObject(forKey: key)
    }
    
    UserDefaults.standard.synchronize()
}

struct SearchView_Previews: PreviewProvider {
    @State static var LoggingStatus = isLoggedIn()
    static var previews: some View {
        SearchUser(fetcher: InstaDataFetcher.init(), username: "Test", wait: false, LoggingStatus: $LoggingStatus)
    }
}
