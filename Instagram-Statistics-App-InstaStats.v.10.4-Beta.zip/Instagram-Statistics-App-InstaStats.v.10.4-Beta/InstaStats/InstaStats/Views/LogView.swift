//
//  LogView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 15/01/21.
//

import SwiftUI
import UIKit
import AAInfographics

struct LogView: View {
    @ObservedObject var fetcher = InstaDataFetcher()
    @State var refresh = Refresh(started: false, released: false)
    
    @State var startIsPresented = false
    
    var rkManager2 = RKManager(calendar: Calendar.current, minimumDate: Date(), maximumDate: Date(), mode: 1) // automatically goes to mode=2 after start selection, and vice versa.
    
    var body: some View {
        
        ZStack {
            Image("BGImage1")
                .resizable()
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
                .offset(y: -10)
            
            ScrollView(.vertical, showsIndicators: false, content: {
                
                GeometryReader { reader -> AnyView in
                    
                    DispatchQueue.main.async {
                        
                        if refresh.startOffset == 0 {
                            refresh.startOffset = reader.frame(in: .global).minY
                        }
                        
                        refresh.offset = reader.frame(in: .global).minY
                        
                        if refresh.offset - refresh.startOffset > 70 && !refresh.started {
                            
                            let impactHeavy = UIImpactFeedbackGenerator(style: .heavy)
                            impactHeavy.impactOccurred()
                            
                            refresh.started = true
                        }
                        
                        if refresh.startOffset == refresh.offset && refresh.started && !refresh.released {
                            
                            if StillNotFuckedUp() && CanRefresh() {
                                print("Manual Update")
                                
                                self.fetcher.username = UserDefaults.standard.object(forKey: "username") as! String
                                self.fetcher.load()
                                
                                UpdateRefrences()
                                
                                UpdateHighestFollowerCount()
                                UpdateLowestFollowerCount()
                                
                                UpdateGainLoss()
                                
                                DoLogs()
                                
                                print(GetFollows())
                                print(GetUnFollows())
                                print(GetOverall())
                                print(GetDays())
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5 ) {
                                    SetRefresh()
                                    
                                }
                                
                            } else {
                                print("Can't Refresh")
                            }
                            
                            UpdateFunc()
                            
                            let impactHeavy = UIImpactFeedbackGenerator(style: .heavy)
                            impactHeavy.impactOccurred()
                            
                            withAnimation(Animation.linear) {
                                refresh.released = true
                            }
                            
                        }
                        
                        if refresh.startOffset == refresh.offset && refresh.started && refresh.released && refresh.invalid {
                            refresh.invalid = false
                            UpdateFunc()
                        }
                        
                    }
                    return AnyView(Color.black.frame(width: 0, height: 0))
                    
                }.frame(width: 0, height: 0)
                
                ZStack {
                    if refresh.started && refresh.released {
                        
                        ProgressView()
                            .scaleEffect(1.5)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/15.0)
                        
                    }
                    else {
                        Image(systemName: "arrow.down")
                            .font(.system(size: 20, weight: .heavy))
                            .foregroundColor(.gray)
                            .rotationEffect(.init(degrees: refresh.started ? 180 : 0))
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height * -0.0495)
                            .animation(.easeIn)
                    }
                    
                    BlurView(style: .systemUltraThinMaterial)
                        .cornerRadius(25)
                        .padding(.horizontal, 20)
                        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 0.5)
                    
                    //MARK:- CHART VIEW
                    
                    VStack {
                        
                        HStack{
                            
                            Button(action : {
                                self.startIsPresented.toggle()
                            }) {
                                HStack(spacing: -15) {
                                    Text("Last 7 Days")
                                        .foregroundColor(.primary)
                                        .font(.system(size: 12)
                                        .bold())
                                        .padding(.horizontal,15)
                                        .padding(.vertical,10)
                                    
                                    Image(systemName: "chevron.down")
                                        .foregroundColor(.primary)
                                        .padding(.all,5)
                                }
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.gray, lineWidth: 2)
                                )
                                
                            }
                            .padding(.vertical,100)
                            .padding(.leading, 15)
                            .sheet(isPresented: self.$startIsPresented, content: {
                                CalendarViewController()
                                //RKViewController(isPresented: self.$startIsPresented, rkManager: self.rkManager2)
                            })
                            
                            Spacer()
                            
                            Text("Aug 31 - Sep 6")
                                .font(.system(size: 12))
                                .bold()
                                .padding(.horizontal,15)
                                .padding(.vertical,10)
                                .padding(.trailing, 15)
                        }
                        
                        Text(self.getTextFromDate(date: self.rkManager2.startDate))
                        Text(self.getTextFromDate(date: self.rkManager2.endDate))
                        
                        Spacer()
                        
                    }.padding(.top,50)
                    
                    ChartView()
                        .padding(.horizontal, 20)
                        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 0.5)
                    
                    
                    
                    //MARK:- CHART VIEW
                    
                    if refresh.released && StillNotFuckedUp() && CanRefresh() {
                        Text("  Account Refreshing...  ")
                            .font(.headline)
                            .padding(.vertical, 10)
                            .foregroundColor(Color(#colorLiteral(red: 0.8609973575, green: 0.8609973575, blue: 0.8609973575, alpha: 1)))
                            .background(Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)))
                            .cornerRadius(10)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/1.25)
                        
                    }
                    
                    
                    if !StillNotFuckedUp() {
                        if refresh.released {
                            VStack {
                                Text(" You are now on Cooldown ")
                                    .font(.headline)
                                Text(" Please wait 24 hours to try Again ")
                            }
                            .padding(.vertical, 10)
                            .foregroundColor(Color(#colorLiteral(red: 0.8609973575, green: 0.8609973575, blue: 0.8609973575, alpha: 1)))
                            .background(Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)))
                            .cornerRadius(10)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/1.25)
                            
                        }
                    }
                    
                    if !CanRefresh() {
                        if refresh.released {
                            VStack {
                                Text("Hold on Dude! , Take a break ")
                                    .font(.headline)
                                Text(" Please wait 30 Seconds")
                            }
                            .padding(.all, 10)
                            .foregroundColor(Color(#colorLiteral(red: 0.8609973575, green: 0.8609973575, blue: 0.8609973575, alpha: 1)))
                            .background(Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)))
                            .cornerRadius(10)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/1.25)
                        }
                    }
                    
                }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                
            })
            
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        
    }
    
    func getTextFromDate(date: Date!) -> String {
        let formatter = DateFormatter()
        formatter.locale = .current
        formatter.dateFormat = "EEEE, MMMM d, yyyy"
        return date == nil ? "" : formatter.string(from: date)
    }
    
    func UpdateFunc() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5 ) {
            withAnimation(Animation.linear) {
                
                if refresh.startOffset == refresh.offset {
                    refresh.released = false
                    refresh.started = false
                }
                else{
                    refresh.invalid = true
                }
            }
        }
    }
    
    struct Refresh {
        var startOffset: CGFloat = 0
        var offset: CGFloat = 0
        var started: Bool = false
        var released: Bool = false
        var invalid: Bool = false
    }
    
}

struct LogView_Previews: PreviewProvider {
    static var previews: some View {
        LogView()
            .preferredColorScheme(.dark)
    }
}
