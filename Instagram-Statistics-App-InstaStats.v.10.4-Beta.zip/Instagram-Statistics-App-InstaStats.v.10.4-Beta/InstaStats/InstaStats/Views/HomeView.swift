//
//  ContentView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 29/12/20.
//

import WidgetKit
import SwiftUI
import SDWebImageSwiftUI

struct HomeView: View {
    
    @ObservedObject var fetcher = InstaDataFetcher()
    @State var LoggingStatus = isLoggedIn()
    @State var refresh = Refresh(started: false, released: false)
    
    var body: some View {
        
        ZStack {
            Image("BGImage1")
                .resizable()
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
                .offset(y: -10)
            
            ScrollView(.vertical, showsIndicators: false, content: {
                
                GeometryReader { reader -> AnyView in
                    
                    DispatchQueue.main.async {
                        
                        if refresh.startOffset == 0 {
                            refresh.startOffset = reader.frame(in: .global).minY
                        }
                        
                        refresh.offset = reader.frame(in: .global).minY
                        
                        if refresh.offset - refresh.startOffset > 70 && !refresh.started {
                            
                            let impactHeavy = UIImpactFeedbackGenerator(style: .heavy)
                            impactHeavy.impactOccurred()
                            
                            refresh.started = true
                        }
                        
                        if refresh.startOffset == refresh.offset && refresh.started && !refresh.released {
                            
                            if StillNotFuckedUp() && CanRefresh() {
                                print("Manual Update")
                                
                                self.fetcher.username = UserDefaults.standard.object(forKey: "username") as! String
                                self.fetcher.load()
                                
                                UpdateRefrences()
                                
                                UpdateHighestFollowerCount()
                                UpdateLowestFollowerCount()
                                
                                UpdateGainLoss()
                                
                                DoLogs()
                                
                                print(GetFollows())
                                print(GetUnFollows())
                                print(GetOverall())
                                print(GetDays())
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5 ) {
                                    SetRefresh()
                                }
                                
                            } else {
                                print("Can't Refresh")
                            }
                            
                            UpdateFunc()
                            
                            let impactHeavy = UIImpactFeedbackGenerator(style: .heavy)
                            impactHeavy.impactOccurred()
                            
                            withAnimation(Animation.linear) {
                                refresh.released = true
                            }
                            
                        }
                        
                        if refresh.startOffset == refresh.offset && refresh.started && refresh.released && refresh.invalid {
                            refresh.invalid = false
                            UpdateFunc()
                        }
                        
                    }
                    return AnyView(Color.black.frame(width: 0, height: 0))
                    
                }.frame(width: 0, height: 0)
                
                
                
                ZStack {
                    
                    if refresh.started && refresh.released {
                        
                        ProgressView()
                            .scaleEffect(1.5)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/15.0)
                        
                    }
                    else {
                        Image(systemName: "arrow.down")
                            .font(.system(size: 20, weight: .heavy))
                            .foregroundColor(.gray)
                            .rotationEffect(.init(degrees: refresh.started ? 180 : 0))
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height * -0.0495)
                            .animation(.easeIn)
                    }
                    
                    //MARK:- INSTADATAVIEW
                    
                    InstaDataView(LoggingStatus: self.$LoggingStatus)
                    
                    //MARK:- INSTADATAVIEW

                    if refresh.released && StillNotFuckedUp() && CanRefresh() {
                        Text("  Account Refreshing...  ")
                            .font(.headline)
                            .padding(.vertical, 10)
                            .foregroundColor(Color(#colorLiteral(red: 0.8609973575, green: 0.8609973575, blue: 0.8609973575, alpha: 1)))
                            .background(Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)))
                            .cornerRadius(10)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/1.25)
                    }
                    
                    
                    if !StillNotFuckedUp() {
                        if refresh.released {
                            VStack {
                                Text(" You are now on Cooldown ")
                                    .font(.headline)
                                Text(" Please wait 24 hours to try Again ")
                            }
                            .padding(.vertical, 10)
                            .foregroundColor(Color(#colorLiteral(red: 0.8609973575, green: 0.8609973575, blue: 0.8609973575, alpha: 1)))
                            .background(Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)))
                            .cornerRadius(10)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/1.25)
                        }
                    }
                    
                    if !CanRefresh() {
                        if refresh.released {
                            VStack {
                                Text("Hold on Dude! , Take a break ")
                                    .font(.headline)
                                Text(" Please wait 30 Seconds")
                            }
                            .padding(.all, 10)
                            .foregroundColor(Color(#colorLiteral(red: 0.8609973575, green: 0.8609973575, blue: 0.8609973575, alpha: 1)))
                            .background(Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)))
                            .cornerRadius(10)
                            .position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/1.25)
                        }
                    }
                    
                }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                
            })
            
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        
    }
    
    func UpdateFunc() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5 ) {
            withAnimation(Animation.linear) {
                
                if refresh.startOffset == refresh.offset {
                    refresh.released = false
                    refresh.started = false
                }
                else{
                    refresh.invalid = true
                }
            }
        }
    }
    
    struct Refresh {
        var startOffset: CGFloat = 0
        var offset: CGFloat = 0
        var started: Bool = false
        var released: Bool = false
        var invalid: Bool = false
    }
    
}
