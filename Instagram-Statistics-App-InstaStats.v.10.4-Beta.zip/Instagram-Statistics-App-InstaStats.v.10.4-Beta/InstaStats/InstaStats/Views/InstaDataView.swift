//
//  InstaDataView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 01/05/21.
//

import WidgetKit
import SwiftUI
import SDWebImageSwiftUI

struct InstaDataView: View {
    
    @ObservedObject var fetcher = InstaDataFetcher()
    
    @Binding var LoggingStatus: Bool
    
    var ProfilePic = UserDefaults.standard.object(forKey: "ProfilePic")
    
    var NewFollowerCount = UserDefaults.standard.integer(forKey: "NewFollowerCount")
    
    let gain = GetGain()
    let loss = GetLoss()
    
    var body: some View {
        
        ZStack {
            
            BlurView(style: .systemUltraThinMaterial)
                .cornerRadius(40)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 1)
                .position(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height / 0.92)

            VStack {

                WebImage(url: URL(string: ProfilePic as? String ?? ""))
                    .resizable()
                    .placeholder(Image(systemName: "person.crop.circle"))
                    .transition(.fade(duration: 0.5))
                    .scaledToFit()
                    .frame(width: 150, height: 150, alignment: .center)
                    .clipShape(Circle())
                
                Text(UserDefaults.standard.object(forKey: "FullName") as? String ?? "")
                    .font(.title)
                    .padding()
                
                ZStack {
                    
                    BlurView(style: .systemUltraThinMaterial)

                    VStack {
                        
                        Text("Followers")
                            .padding(.all,1)
                            .foregroundColor(.primary)
                        
                        Text(NewFollowerCount as NSObject,formatter: NumberFormatter.format)
                            .font(.system(size: UIScreen.main.bounds.width * 0.15))
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                        
                        HStack(spacing: 130) {
                            
                            HStack {
                                Image(systemName: "arrowtriangle.up.fill")
                                    .foregroundColor(.green)
                                
                                Text(gain as NSObject,formatter: NumberFormatter.format)
                                    .foregroundColor(.green)
                            }
                            
                            HStack {
                                Image(systemName: "arrowtriangle.down.fill")
                                    .foregroundColor(.red)
                                
                                Text(loss as NSObject,formatter: NumberFormatter.format)
                                    .foregroundColor(.red)
                            }
                            
                        }.padding(3)
                        
                    }

                }
                .frame(width: UIScreen.main.bounds.width * 0.90, height: UIScreen.main.bounds.height * 0.25)
                .cornerRadius(25)
                
                
            }//.position(x: UIScreen.main.bounds.width/2,y: UIScreen.main.bounds.height/2.125)
            
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .ignoresSafeArea(edges: .all)
        
    }
    
}


struct InstaDataView_Previews: PreviewProvider {
    @State static var LoggingStatus = isLoggedIn()
    
    static var previews: some View {
        InstaDataView(LoggingStatus: $LoggingStatus)
    }
}
