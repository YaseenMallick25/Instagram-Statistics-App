//
//  ChartView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 15/01/21.
//

import SwiftUI
import UIKit
import AAInfographics

struct ChartView: UIViewRepresentable {
    @State var follows = GetFollows()
    @State var unfollows = GetUnFollows()
    @State var overall = GetOverall()
    
    func updateUIView(_ uiView: AAChartView, context: Context) {
                
        uiView.aa_onlyRefreshTheChartDataWithChartModelSeries(configureSeriesDataArray(), animation: true)
        uiView.aa_updateXAxisCategories(GetDays())
        uiView.aa_adaptiveScreenRotation()
        
    }
    
    func makeUIView(context: Context) -> AAChartView {
        
        let aaChartView = AAChartView()
        
        aaChartView.frame = CGRect(x: 0,
                                   y: 60,
                                   width: UIScreen.main.bounds.width,
                                   height: UIScreen.main.bounds.height)
        
        aaChartView.scrollEnabled = false
        aaChartView.isClearBackgroundColor = true

        aaChartView.aa_drawChartWithChartOptions(configureAAOption())
        
        return aaChartView
        
    }
    
}

func GetaaChartModel() -> AAChartModel {
    
    let aaChartModel = AAChartModel()
    
        aaChartModel
            .chartType(.line)
            .animationType(.linear)
            .title("Follows Breakdown")
            .titleStyle(AAStyle(color: "lightGray"))
            .subtitle("vs")
            .subtitleStyle(AAStyle(color: "darkGray"))
            .categories(GetDays())
            .colorsTheme(["#06caf4","#ffc069","#fe117c"])
            .zoomType(.xy)
            .scrollablePlotArea(AAScrollablePlotArea())
            .series(configureSeriesDataArray())
    
    return aaChartModel
}

func configureAAOption() -> AAOptions {
    let aaOptions = AAOptionsConstructor.configureChartOptions(GetaaChartModel())
    
    aaOptions.legend!
        .symbolRadius(15)
        .symbolHeight(15)
        .symbolWidth(15)
        .itemStyle(AAItemStyle()
                    .color(AAColor.gray)
                    .fontSize(15)
                    .fontWeight(.regular))
    
    return aaOptions
}

func configureSeriesDataArray() -> [AASeriesElement] {
    let overall = Array(1...10)
    let follows = Array(1...10)
    let unfollows = Array(1...10)
    
    let overallResult = overall[range: 0...5] as Array
    let followsResult = follows[range: 0...5] as Array
    let unfollowsResult = unfollows[range: 0...5] as Array
    
    let chartSeriesArray = [
        AASeriesElement()
            .name("Overall")
            .type(.area)
            //.data(overallResult),
            //.data(GetOverall()),
            .data([73, 10, -20, -22, 8, 11, 31, 30, -6, 11, 20, 19, -34, -22, 1, 6]),

        AASeriesElement()
            .name("Follows")
            //.data(followsResult),
            //.data(GetFollows()),
            .data([87, 28, 11, 56, 23, 24, 55, 53, 17, 23, 37, 51, 25, 10, 20, 32]),

        AASeriesElement()
            .name("Unfollows")
            //.data(unfollowsResult),
            //.data(GetUnFollows()),
            .data([14, 18, 31, 78, 15, 13, 24, 23, 17, 12, 17, 32, 59, 32, 19, 26]),
        
    ]
    
    return chartSeriesArray
    
}

struct ChartView_Previews: PreviewProvider {
    static var previews: some View {
        ChartView()
            .preferredColorScheme(.dark)
    }
}
