//
//  CalenderView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 14/09/21.
//

import SwiftUI
import HorizonCalendar

struct CalendarViewController: UIViewRepresentable {
    
    func makeUIView(context: Context) -> CalendarView {
        let calendarView = CalendarView(initialContent: makeContent())
        return calendarView
    }

    func updateUIView(_ uiView: CalendarView, context: UIViewRepresentableContext<CalendarViewController>) {}

    private func makeContent() -> CalendarViewContent {
        var calendar = Calendar(identifier: .gregorian)
        calendar.locale = Locale.current
        
        let startDate = calendar.date(from: DateComponents(year: 2020, month: 01, day: 01))!
        let endDate = calendar.date(from: DateComponents(year: 2021, month: 12, day: 31))!
        
        return CalendarViewContent(
            calendar: calendar,
            visibleDateRange: startDate...endDate,
            monthsLayout: .vertical(
                options:VerticalMonthsLayoutOptions(
                    pinDaysOfWeekToTop: true
                )
            )
        )
        
    }

}


struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarViewController()
            .preferredColorScheme(.dark)
    }
}

