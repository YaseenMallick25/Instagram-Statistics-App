//
//  TestView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 04/05/21.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var fetcher = InstaDataFetcher()
    @State var LoggingStatus = isLoggedIn()
    
    var body: some View {
        
        TabView{
            HomeView()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            
            LogView()
                .tabItem {
                    Image(systemName: "chart.bar")
                    Text("Breakdown")
                }
            
            ZStack {
                Image("BGImage1")
                    .resizable()
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)
                    .offset(y: -10)
                
                Button(action: {
                    LoggedOut()
                    self.LoggingStatus = false
                }) {
                    Image(systemName: "power")
                        .scaleEffect(2.5)
                        .padding(.all,40)
                    Text("Log Out")
                }
                .buttonStyle(SimpleButtonStyle())
                
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: .center)

            .tabItem {
                Image(systemName: "arrow.right.square")
                Text("LogOut")
            }
            
        }.onAppear(perform: {
            if StillNotFuckedUp() && CanRefresh() {
                print("Doing Auto Refesh")
                
                self.fetcher.username = UserDefaults.standard.object(forKey: "username") as! String
                self.fetcher.load()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5 ) {
                    SetRefresh()
                    
                    UpdateRefrences()
                    
                    UpdateHighestFollowerCount()
                    UpdateLowestFollowerCount()
                    
                    UpdateGainLoss()
                    
                    print("here")
                    DoLogs()
                    
                }
            } else {
                print("Can't Auto Refresh")
            }
        })
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
