//
//  BGView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 13/04/21.
//

import SwiftUI

struct BGView: View {
    var body: some View {
        
        ZStack {
            Wave1()
                .fill(LinearGradient(gradient: Gradient(colors: [Color("W1BGColor1"),Color("W1BGColor2"),Color("W1BGColor3")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                .blur(radius: 30)
            
            Wave2()
                .fill(LinearGradient(gradient: Gradient(colors: [Color("W2BGColor1"),Color("W2BGColor2"),Color("W2BGColor3")]), startPoint: .topTrailing, endPoint: .bottomTrailing))
                .blur(radius: 30)
            
        }
    }
}



struct Wave1 : Shape {

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY + 300))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        path.addQuadCurve(to: CGPoint(x: rect.minX, y: rect.minY + 300), control: CGPoint(x: rect.midX - 150, y: rect.midY + 260))

        return path
    }
}

struct Wave2 : Shape {

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.maxX, y: rect.minY + 100))
        path.addLine(to : CGPoint(x : rect.maxX, y : rect.maxY))
        path.addLine(to : CGPoint(x : rect.minX, y : rect.maxY))
        path.addQuadCurve(to : CGPoint(x : rect.maxX, y : rect.minY + 100), control : CGPoint(x : rect.midX + 150, y : rect.midY + 260))

        return path
    }
}

struct BGView_Previews: PreviewProvider {
    static var previews: some View {
        BGView()
            .preferredColorScheme(.dark)
            
    }
}
