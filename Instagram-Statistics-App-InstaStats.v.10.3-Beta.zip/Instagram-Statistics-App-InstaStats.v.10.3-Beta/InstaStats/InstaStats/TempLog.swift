//
//  Log.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 19/04/21.
//
import SwiftUI
import Foundation

// MARK: - TempLogFollows

func SetTempFollows(Set_Temp_Follows : Array<Int>) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Set_Temp_Follows, forKey: "TempLogFollows")
    UserDefaults.standard.synchronize()
}

func GetTempFollows() -> Array<Int> {
    let TempFollows = UserDefaults(suiteName: "group.InstaStats")?.object(forKey: "TempLogFollows") as? [Int] ?? []
    return TempFollows
}

func SetTempLogRefrenceFollowsCount(Temp_Log_Refrence_FollowsCount : Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Temp_Log_Refrence_FollowsCount, forKey: "TempLogRefrenceFollowsCount")
    UserDefaults.standard.synchronize()
}

func GetTempLogRefrenceFollowsCount() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "TempLogRefrenceFollowsCount")
}

func UpdateTempLogFollowsRefrences() {
    SetTempLogRefrenceFollowsCount(Temp_Log_Refrence_FollowsCount : GetNewFollowerCount())
}

func AppendTempFollows() {
    var TempFollows = GetTempFollows()
    
    let NewFollowerCount = GetNewFollowerCount()
    
    let DiffCount = NewFollowerCount - GetTempLogRefrenceFollowsCount()
    print("Follows DiffCount")
    print(DiffCount)
    
    if DiffCount > 0 {
        TempFollows.append(DiffCount)
        SetTempFollows(Set_Temp_Follows: TempFollows)
        UserDefaults.standard.synchronize()
    }/* else {
        TempFollows.append(0)
        SetTempFollows(Set_Temp_Follows: TempFollows)
        UserDefaults.standard.synchronize()
     }*/
    
    
    /*
    TempFollows.append(GetGains())
    SetTempFollows(Set_Temp_Follows: TempFollows)
    */
    
    UpdateTempLogFollowsRefrences()
    UserDefaults.standard.synchronize()
    
}



// MARK: - TempLogUnfollows

func SetTempUnfollows(Set_Temp_Unfollows : Array<Int>) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Set_Temp_Unfollows, forKey: "TempLogUnfollows")
    UserDefaults.standard.synchronize()
}

func GetTempUnfollows() -> Array<Int> {
    let TempUnfollows = UserDefaults(suiteName: "group.InstaStats")?.object(forKey: "TempLogUnfollows") as? [Int] ?? []
    return TempUnfollows
}

func SetTempLogRefrenceUnfollowsCount(Temp_Log_Refrence_UnfollowsCount : Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Temp_Log_Refrence_UnfollowsCount, forKey: "TempLogRefrenceUnfollowsCount")
    UserDefaults.standard.synchronize()
}

func GetTempLogRefrenceUnfollowsCount() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "TempLogRefrenceUnfollowsCount")
}

func UpdateTempLogUnfollowsRefrences() {
    SetTempLogRefrenceUnfollowsCount(Temp_Log_Refrence_UnfollowsCount : GetNewFollowerCount())
}

func AppendTempUnfollows() {
    var TempUnfollows = GetTempUnfollows()
    
    let NewUnfollowerCount = GetNewFollowerCount()
    
    let DiffCount = GetTempLogRefrenceUnfollowsCount() - NewUnfollowerCount
    print("Unfollows Diffcount")
    print(DiffCount)
    
    if DiffCount > 0 {
        TempUnfollows.append(DiffCount)
        SetTempUnfollows(Set_Temp_Unfollows: TempUnfollows)
        UserDefaults.standard.synchronize()
    } /* else {
        TempUnfollows.append(0)
        SetTempUnfollows(Set_Temp_Unfollows: TempUnfollows)
        UserDefaults.standard.synchronize()
    }*/
    
    
    /*
    var loss = GetLoss()
    loss.negate()
    
    TempUnfollows.append(loss)
    SetTempUnfollows(Set_Temp_Unfollows: TempUnfollows)
    */
    
    UpdateTempLogUnfollowsRefrences()
    UserDefaults.standard.synchronize()
}


// MARK: - TempLogOverall

func SetTempOverall(Set_Temp_Overall : Array<Int>) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Set_Temp_Overall, forKey: "TempLogOverall")
    UserDefaults.standard.synchronize()
}

func GetTempOverall() -> Array<Int> {
    let TempOverall = UserDefaults(suiteName: "group.InstaStats")?.object(forKey: "TempLogOverall") as? [Int] ?? []
    return TempOverall
}

func SetTempLogRefrenceOverallCount(Temp_Log_Refrence_OverallCount : Int) {
    UserDefaults(suiteName: "group.InstaStats")!.set(Temp_Log_Refrence_OverallCount, forKey: "TempLogRefrenceOverallCount")
    UserDefaults.standard.synchronize()
}

func GetTempLogRefrenceOverallCount() -> Int {
    return UserDefaults(suiteName: "group.InstaStats")!.integer(forKey: "TempLogRefrenceOverallCount")
}

func UpdateTempLogOverallRefrences() {
    SetTempLogRefrenceOverallCount(Temp_Log_Refrence_OverallCount : GetNewFollowerCount())
}

func AppendTempOverall() {
    var TempOverall = GetTempOverall()
    
    let diffCount = GetTempFollows().last! - GetTempUnfollows().last!
    print("DiffCount Overall")
    print(diffCount)
    
    TempOverall.append(diffCount)
    
    SetTempOverall(Set_Temp_Overall: TempOverall)
    UserDefaults.standard.synchronize()

    UpdateTempLogOverallRefrences()
    UserDefaults.standard.synchronize()
}
