//
//  Backup_InstaStatsApp.swift
//  Backup InstaStats
//
//  Created by Yaseen Mallick on 08/01/21.
//

import SwiftUI

@main
struct Backup_InstaStatsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
