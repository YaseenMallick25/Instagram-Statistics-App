//
//  BlurView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 12/04/21.
//

import Foundation
import SwiftUI
import UIKit

struct BlurView : UIViewRepresentable {
    
    var style : UIBlurEffect.Style
    
    func makeUIView(context: Context) ->  UIVisualEffectView {
        
        let view = UIVisualEffectView(effect : UIBlurEffect(style : style))
        
        return view
    }
    
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        uiView.effect = UIBlurEffect(style: style)
    }
    
}
