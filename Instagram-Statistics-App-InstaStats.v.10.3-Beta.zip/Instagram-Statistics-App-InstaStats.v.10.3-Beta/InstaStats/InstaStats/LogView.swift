//
//  LogView.swift
//  InstaStats
//
//  Created by Yaseen Mallick on 15/01/21.
//

import SwiftUI
import UIKit
import AAInfographics

struct LogView: View {
    var body: some View {

        ZStack {
            
            BlurView(style: .systemUltraThinMaterial)
                .shadow(color: Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)), radius: 10, x: -10, y: 10)
            
            ChartView()
        }
        .cornerRadius(25)

    }
}

struct LogView_Previews: PreviewProvider {
    static var previews: some View {
        LogView()
    }
}
