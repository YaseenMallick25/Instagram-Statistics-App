
import SwiftUI
import AAInfographics

struct ChartView: UIViewRepresentable {
    func updateUIView(_ uiView: AAChartView, context: Context) {
        
    }
        
    func makeUIView(context: Context) -> AAChartView {
        
        //let overall = [Int]()
        
        //ForEach(logs,id: \.Date){ logs in
        //}
        
        //let arr = [1,2,3,4,56]
        
        let aaChartView = AAChartView()
        
        aaChartView.frame = CGRect(x: 0,
                                    y: 60,
                                    width: UIScreen.main.bounds.width,
                                    height: UIScreen.main.bounds.height)

        aaChartView.scrollEnabled = false
        aaChartView.isClearBackgroundColor = true
        
        let aaChartModel = AAChartModel()
        .chartType(.line)//Can be any of the chart types listed under `AAChartType`.
        .animationType(.bounce)
        .title("Follows Breakdown")//The chart title
        .subtitle("subtitle")//The chart subtitle
        .categories(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])
        .colorsTheme(["#06caf4","#ffc069","#fe117c"])

        .series([
            AASeriesElement()
                .name("Overall")
                .type(.area)
                //.data(GetTempOverall()),
                .data([67, -28, 11, 56, 13, -24, 5]),
            AASeriesElement()
                .name("Follows")
                //.data(GetTempFollows()),
                .data([84, 3, 31, 78, 13, 7, 24]),
            AASeriesElement()
                .name("Unfollows")
                //.data(GetTempUnfollows()),
                .data([17, 31, 20, 22, 25, 31, 20]),
                ])
        
        aaChartView.aa_drawChartWithChartModel(aaChartModel)

        return aaChartView
    }
}


